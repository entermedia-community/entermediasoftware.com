mv /vol/share­/tomcat/we­bapps/mana­ger /vol/share­/tomcat/we­bapps/serv­ermanager
sh ./entermedia-rehel.run
