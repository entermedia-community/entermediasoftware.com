SITE="http://www.whitacrecomputers.com/linux"
wget $SITE/libx264-normal.ffpreset
wget $SITE/yasm-1.2.0.tar.gz
wget $SITE/opencore-amr-0.1.2.tar.gz
wget $SITE/libraw1394-1.3.0.tar.gz
wget $SITE/libdc1394-1.2.2.tar.gz
wget $SITE/libdc1394-2.1.2.tar.gz
wget $SITE/faad2-2.6.1.tar.gz
wget $SITE/faac-1.26.tar.gz
wget $SITE/lame-3.98.4.tar.gz
wget $SITE/openjpeg_v1_3.tar.gz
wget $SITE/libogg-1.1.4.tar.gz
wget $SITE/libvorbis-1.2.3.tar.gz
wget $SITE/vorbis-tools-1.2.0.tar.gz
wget $SITE/libtheora-1.1.1.tar.bz2
wget $SITE/xvidcore-1.2.2.tar.gz
wget $SITE/gpac-0.4.5.tar.gz
wget $SITE/gpac_extra_libs-0.4.5.tar.gz
wget $SITE/ruby-1.9.0-5.tar.gz
wget $SITE/flvtool2-1.0.6.tgz
wget $SITE/yamdi-1.5.tar.gz
wget $SITE/NeroDigitalAudio.zip
wget $SITE/jre-6u26-linux-i586-rpm.bin
wget $SITE/jre-6u26-linux-x64-rpm.bin
wget $SITE/tomcat.tgz
wget http://dev.entermediasoftware.com/jenkins/job/entermedia-server/lastSuccessfulBuild/artifact/deploy/ROOT.war

