assert()
{
FILE=$1
if [ -f $FILE ];
then
        echo "File $FILE exists."
        rm $FILE
else
        echo "File $FILE does NOT exist.!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
       exit 0;
fi
#rm $FILE
}



convert baby.jpg  bout.jpg
assert bout.jpg

##If this fails you need to build/install ufraw and recompile imagemagick
convert IMG_0192.CR2  cr2out.jpg
assert cr2out.jpg

##This depends on yum install libtiff and recompile imagemagick
convert cc.tif tifout.jpg
assert tifout.jpg

##This depends on the correct ~/.ffmpeg/libx264-normal.ffpreset existing
ffmpeg -i cb1sampleiTunes4.mov -y -acodec libfaac -ab 96k -ar 44100 -ac 1 -vcodec libx264 -vpre normal -crf 28 -threads 0 -s 704x480 outtmp.mp4
#assert outtmp.mp4

##This depends on make tools/qt-faststa­rt
qt-faststart outtmp.mp4 qtout.mp4
assert qtout.mp4

##this tends to work
ffmpeg -ss 2 -deinterlace -i cb1sampleiTunes4.mov  -y -vframes 1 -f mjpeg ffmpegout.jpg
assert ffmpegout.jpg

##this tends to work ok
convert -density 200 agenda.pdf[0]  -colorspace rgb -strip pdfout.jpg
assert pdfout.jpg

echo "All tests pass!"

